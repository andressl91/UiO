#include "parallel_main.h"

void test(){
    printf("hello \n");
}
